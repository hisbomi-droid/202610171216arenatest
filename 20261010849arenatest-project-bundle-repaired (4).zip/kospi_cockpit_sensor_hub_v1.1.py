from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd


def generate_mock_daily_bars(n_days: int = 250) -> pd.DataFrame:
    idx = pd.date_range("2024-01-01", periods=n_days, freq="B")
    base = np.linspace(100, 140, n_days)
    trend = np.linspace(0.0, 0.12, n_days)
    noise = np.sin(np.arange(n_days) / 6.0) * 1.2
    close = base * (1 + trend) + noise
    open_ = close * (1 - np.linspace(0.003, 0.01, n_days))
    high = np.maximum(open_, close) * (1 + np.linspace(0.005, 0.015, n_days))
    low = np.minimum(open_, close) * (1 - np.linspace(0.005, 0.015, n_days))
    vol = (np.abs(np.linspace(1000, 6000, n_days)) + np.random.default_rng(7).normal(0, 300, n_days)).astype(int)
    return pd.DataFrame({
        "open": open_,
        "high": high,
        "low": low,
        "close": close,
        "volume": vol,
    }, index=idx)


def generate_mock_intraday_bars(n_bars: int = 500, start: str = "2024-01-01 09:00") -> pd.DataFrame:
    idx = pd.date_range(start, periods=n_bars, freq="5min")
    base = np.linspace(100, 120, n_bars)
    noise = np.sin(np.arange(n_bars) / 8.0) * 2.0
    close = base + noise
    open_ = close * (1 - np.linspace(0.001, 0.005, n_bars))
    high = np.maximum(open_, close) * (1 + np.linspace(0.002, 0.008, n_bars))
    low = np.minimum(open_, close) * (1 - np.linspace(0.002, 0.008, n_bars))
    volume = (np.abs(np.linspace(150, 700, n_bars)) + np.random.default_rng(11).normal(0, 50, n_bars)).astype(int)
    return pd.DataFrame({
        "open": open_,
        "high": high,
        "low": low,
        "close": close,
        "volume": volume,
    }, index=idx)


class TIRSensor:
    using_real_module = False

    def compute(self, df_daily: pd.DataFrame) -> pd.DataFrame:
        out = df_daily.copy()
        out["tir_event"] = out["close"].pct_change().abs().gt(0.012)
        return out


class FrictionAdapter:
    using_real_engine = False

    def compute(self, df_intraday: pd.DataFrame) -> pd.DataFrame:
        out = df_intraday.copy()
        out["friction_score"] = np.linspace(0.1, 0.9, len(out))
        return out


class KospiCockpitSensorHub:
    def __init__(self):
        self.tir_sensor = TIRSensor()
        self.friction_adapter = FrictionAdapter()

    def run(self, df_intraday: pd.DataFrame, df_daily: pd.DataFrame) -> pd.DataFrame:
        intraday = df_intraday.copy()
        intraday["Q_z"] = (intraday["close"] - intraday["close"].mean()) / (intraday["close"].std(ddof=0) or 1.0)
        intraday["friction_score"] = np.linspace(0.2, 0.9, len(intraday))
        intraday["friction_spike"] = intraday["friction_score"] > 0.7
        intraday["x_t"] = np.arange(len(intraday))
        intraday["v_t"] = intraday["close"].pct_change().fillna(0).to_numpy()
        intraday["a_t"] = intraday["v_t"].diff().fillna(0).to_numpy()
        daily_events = self.tir_sensor.compute(df_daily)
        event_flags = {
            pd.Timestamp(ts).date(): bool(flag)
            for ts, flag in daily_events["tir_event"].fillna(False).items()
        }
        intraday["tir_event"] = pd.Series(
            [event_flags.get(d, False) for d in intraday.index.date],
            index=intraday.index,
            dtype=bool,
        )
        intraday["cascade_label"] = np.where(
            intraday["friction_spike"], "breakout", np.where(intraday["v_t"].gt(0), "uptrend", "steady")
        )
        intraday["regime_alert"] = intraday["friction_spike"] | intraday["tir_event"]
        return intraday


def record_cascade_predictions(fused: pd.DataFrame, df_intraday: pd.DataFrame, ledger: Any, horizon: int = 30) -> int:
    if fused.empty:
        return 0
    events = fused[fused["regime_alert"] == True]  # noqa: E712
    if events.empty:
        return 0
    added = 0
    for _, row in events.head(horizon).iterrows():
        if hasattr(ledger, "record"):
            ledger.record(
                task="direction",
                prediction={"signal": "long" if row.get("v_t", 0) >= 0 else "short"},
                actual=float(row.get("close", 0.0)),
                timestamp=str(row.name),
                symbol="KOSPI",
                source="cockpit_demo",
            )
            added += 1
    return added
