TIR timestamp-key alignment patch
=================================

Purpose
-------
Fixes a mismatch where record_tir_predictions() stores a timestamp taken from a
column but evaluate_tir_predictions() searches outcomes by the DataFrame index.

Patch behavior
--------------
- Adds a canonical timestamp-index helper.
- Uses timestamp/date/datetime/time columns (in that priority order) when present.
- Otherwise accepts a DatetimeIndex or a parseable non-numeric index.
- Rejects integer-only row labels instead of silently interpreting them as 1970 dates.
- Makes record and evaluate use the same canonical DatetimeIndex.
- Does not modify baseline/v2 functions or load_market_data().
- Writes a separate *.timestamp_key_fixed.py output; never overwrites the source.

Usage
-----
Run the patcher against the ACTUAL connected TIR module in your working workspace:

  python patch_tir_timestamp_key_alignment.py /path/to/tir_reflection_backtest_v1_connected.py

Then review the generated file and configure the controller/cockpit to import that
file under the expected module filename/path. Do not replace a working connected
module with the standalone `tir_reflection_backtest_v1_connected.timestamp_key_fixed.py`
from this package without checking its data-loader implementation.

The patcher requires the input module to define all three controller adapter
functions: `record_tir_predictions`, `evaluate_tir_predictions`, and
`summarize_tir_predictions`. If the input is only a re-export wrapper, it stops
without writing output and reports the local implementation module to patch.
The generated sibling is not active until the controller is configured to load it.

Validation performed here
-------------------------
- py_compile passed for the patcher and generated module.
- Synthetic adapter test: DatetimeIndex, integer index + date column, and integer
  index + timestamp column each recorded 152 and evaluated 152; pending count 0.
- Integer-only index with no timestamp/date column fails clearly.
- No real KRX/Naver/Yahoo/network/key integration test was performed.

Important source caveat
-----------------------
The locally available connected file used to validate the patcher contains a
`load_market_data()` stub. Therefore the generated fixed module is provided only
as a reference/test artifact; apply the patcher to the known-good connected file
that has the UME-backed loader, so that loader is preserved.
