from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

KST = timezone.utc


class TradingCalendar:
    @classmethod
    def from_file(cls, path: Path):
        return cls()

    def __init__(self):
        self.holidays = set()


@dataclass
class SessionConfig:
    market_open: str = "09:00"
    market_close: str = "15:30"


class SessionClock:
    def __init__(self, config: SessionConfig, calendar: TradingCalendar):
        self.config = config
        self.calendar = calendar

    def phase(self, now: datetime):
        return "OPEN"


@dataclass
class ContextReadResult:
    ctx: Optional[Dict[str, Any]] = None
    stale: bool = False
    problems: list[str] = None


def read_context(path: Path, expected_asof: Any):
    if not path.exists():
        return ContextReadResult(ctx=None, stale=False, problems=["context file not found"])
    return ContextReadResult(ctx={"regime": "demo", "engine_level": 1}, stale=False, problems=[])
