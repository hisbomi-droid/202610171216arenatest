from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List

import numpy as np
import pandas as pd

REGIME_FIT = {
    "baseline": {"bull": 0.72, "neutral": 0.52, "bear": 0.36},
    "trend": {"bull": 0.78, "neutral": 0.55, "bear": 0.32},
    "breakout": {"bull": 0.81, "neutral": 0.58, "bear": 0.30},
}


def generate_demo_data(n_days: int = 250) -> pd.DataFrame:
    idx = pd.date_range("2024-01-01", periods=n_days, freq="B")
    base = np.linspace(100, 140, n_days)
    drift = np.linspace(0.0, 0.15, n_days)
    noise = np.sin(np.arange(n_days) / 5.0) * 1.5
    closes = base * (1 + drift) + noise
    opens = closes * (1 - np.linspace(0.003, 0.01, n_days))
    highs = np.maximum(opens, closes) * (1 + np.linspace(0.004, 0.012, n_days))
    lows = np.minimum(opens, closes) * (1 - np.linspace(0.004, 0.012, n_days))
    vols = np.abs(np.linspace(1000, 6000, n_days)) + np.random.default_rng(42).normal(0, 200, n_days)
    return pd.DataFrame(
        {
            "timestamp": idx,
            "open": opens,
            "high": highs,
            "low": lows,
            "close": closes,
            "volume": vols.astype(int),
        }
    )


def normalize_bars(bars: Any, provider: str = "demo_replay") -> pd.DataFrame:
    df = bars.copy() if isinstance(bars, pd.DataFrame) else pd.DataFrame(bars)
    if df.empty:
        raise ValueError("No market bars available")
    df = df.copy()
    df.columns = [str(c).lower() for c in df.columns]
    if "timestamp" not in df.columns:
        if df.index.name is not None:
            df["timestamp"] = pd.to_datetime(df.index)
        else:
            df["timestamp"] = pd.date_range("2024-01-01", periods=len(df), freq="D")
    df["timestamp"] = pd.to_datetime(df["timestamp"])
    for field in ("open", "high", "low", "close", "volume"):
        if field not in df.columns:
            raise ValueError(f"Missing required column: {field}")
    if "symbol" not in df.columns:
        df["symbol"] = "KOSPI"
    if "trade_amount" not in df.columns:
        df["trade_amount"] = pd.to_numeric(df["volume"], errors="coerce") * pd.to_numeric(df["close"], errors="coerce")
    df["provider"] = provider
    return df


@dataclass
class ArenaResult:
    regime: str
    current_priority: str
    oos_leader: str
    current_reason: str
    market_state: Dict[str, float]
    predictions: List[Dict[str, Any]]
    oos: pd.DataFrame


class Arena:
    def __init__(self):
        self.last_df = pd.DataFrame()

    def run_backtest_replay(self, df: Any, horizon: int = 5) -> "Arena":
        self.last_df = normalize_bars(df, provider="demo_replay")
        return self

    def evaluate_current(self, df: Any, provider: str = "demo_replay", quality: str = "GOOD") -> ArenaResult:
        x = normalize_bars(df, provider)
        close = pd.to_numeric(x["close"], errors="coerce")
        if close.empty:
            raise ValueError("No close prices for evaluation")
        start = float(close.iloc[0]) if len(close) else 0.0
        end = float(close.iloc[-1]) if len(close) else 0.0
        pct = (end - start) / start if start else 0.0
        regime = "bull" if pct > 0.01 else "bear" if pct < -0.01 else "neutral"
        current_priority = "trend" if abs(pct) > 0.02 else "mean_reversion"
        market_state = {
            "close": end,
            "pct_change": pct,
            "volatility": float(close.pct_change().fillna(0).std() * 100.0),
            "quality": quality,
        }
        predictions = [
            {"model": "baseline", "direction": "long" if pct >= 0 else "short", "strength": abs(pct) * 100.0},
            {"model": "trend", "direction": "long" if pct >= 0 else "short", "strength": max(0.5, abs(pct) * 80.0)},
        ]
        result = ArenaResult(
            regime=regime,
            current_priority=current_priority,
            oos_leader="baseline",
            current_reason=f"Demo strategy score: {pct:.2%} move with {quality} data quality.",
            market_state=market_state,
            predictions=predictions,
            oos=pd.DataFrame(),
        )
        return result
