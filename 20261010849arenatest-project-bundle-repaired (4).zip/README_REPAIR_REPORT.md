# 프로젝트 번들 수정 보고서

## 반영한 수정

1. `kospi_master_controller.py` 및 `kospi_master_controller (4).py`
   - `phase.value` 접근을 안전한 `getattr(phase, "value", str(phase))`로 변경.
   - TIR 원장 처리를 입력 스키마와 ledger API 호환성 확인 뒤에만 실행하도록 방어.
   - TIR 처리 실패가 독립적인 Cockpit 원장 기록 전체를 중단하지 않도록 예외 경계를 분리.
   - 구형 `prediction_ledger.py`의 `dataframe()`/상태 컬럼 부재를 고려해 통계 집계를 호환 처리.
   - 시작 시 UME 어댑터 발견을 실제 데이터 연결 성공으로 표현하지 않도록 배너 문구 수정.
   - 기존 연결 TIR wrapper를 계속 우선 로드하며, 검증되지 않은 참고 패치본을 자동 연결하지 않음.
2. `kospi_cockpit_sensor_hub_v1.1.py`
   - NumPy 배열의 `.map()` 호출을 제거.
   - 일자별 TIR 이벤트를 날짜 키 딕셔너리로 정렬해 분봉에 매핑하고, 중복 날짜 인덱스로 인한 Series truth-value 오류도 방지.
3. `tir_reflection_backtest_v1_connected_timestamp_key_fixed.py`
   - 제공된 `tir_reflection_backtest_v1_connected_runtime_fixed.py`의 Part A/B 및 로더 구현을 보존한 별도 후보 파일 생성.
   - 기록과 평가에서 동일한 정규화 timestamp 키를 사용하도록 어댑터만 수정.
   - 원본 `tir_reflection_backtest_v1.py`는 수정하지 않음.
4. `tests/tir_key_alignment/`
   - A) DatetimeIndex, B) 정수 인덱스 + `date`, C) 정수 인덱스 + `timestamp` 회귀 시험과 격리된 호환 ledger fixture 포함.

## 검증 결과

- Python 구문 컴파일: 프로젝트 내 Python 파일 25개 PASS.
- TIR 타임스탬프 A/B/C 회귀 시험: 3개 모두 PASS. 각 케이스 기록 121건, 평가 121건.
- Cockpit mock 입력 처리: 500개 분봉 처리 성공, `tir_event` boolean dtype 확인.
- 컨트롤러 import: PASS.
- UME 조회 시험: 실제 `universal_quant_engine`이 없으므로 `demo_replay(fallback)`으로 안전하게 폴백하며 `UME_ModuleNotFoundError` 보고. 이는 실제 UME 연결 성공이 아님.

## 아직 검증할 수 없는 항목 / 제한

- ZIP에 `universal_quant_engine` 또는 실제 `kospi_arena` 패키지가 없어 KRX/Naver/Yahoo 및 UME 실데이터 연결은 미검증.
- 기존 루트 `prediction_ledger.py`는 레거시 API이며 timestamp-keyed binary-event evaluation API를 제공하지 않음. 따라서 컨트롤러는 이 원장과 TIR 이벤트 평가를 강행하지 않고, 필요한 입력 컬럼/API가 확인될 때까지 TIR 기록을 건너뜀.
- `tir_reflection_backtest_v1_connected_timestamp_key_fixed.py`는 패치 후보/회귀 시험용이며 컨트롤러에서 자동 활성화하지 않음. 현재 연결 wrapper 및 실제 UME 로더와의 동등성이 입증되지 않았기 때문.
- `state.json`은 업로드 당시의 역사적 스냅샷이므로 현재 런타임 연결 증거로 사용하지 않음.
- 실제 KRX 데이터, 네트워크, API 키, 운영 대시보드 프로세스에 대한 통합시험은 수행하지 않음.

## 실행

번들 폴더에서:
`python kospi_master_controller.py`

실제 UME 연결이 없으면 상태에 `demo_replay(fallback)`이 표시되는 것이 정상입니다.
회귀 시험:
`python tests/tir_key_alignment/test_tir_keyfix_regression.py`
