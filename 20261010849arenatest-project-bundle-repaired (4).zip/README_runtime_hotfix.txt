KOSPI runtime hotfix package

1) kospi_master_controller_stage2_ume_tir_v3_runtime_fixed.py
   - phase Enum/string compatibility fix. Based on v3 UME adapter patch.
2) tir_reflection_backtest_v1_connected_runtime_fixed.py
   - timestamp fallback uses row timestamp when available, otherwise DataFrame index.
3) apply_kospi_runtime_hotfixes.py
   - optional targeted patcher for the exact three source patterns in the traceback.
   - writes separate *.runtime_fixed.py files; never overwrites originals.

Cockpit note: the currently uploaded cockpit source in this session does not contain
`intraday.index.date.map(...)`; the patcher applies that replacement only to the exact
workspace version where the traceback says it exists.

Validation: Python syntax compilation only. No live market data or full server integration
was executed here.
