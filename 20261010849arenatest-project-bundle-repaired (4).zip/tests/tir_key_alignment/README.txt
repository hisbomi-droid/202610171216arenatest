Isolated synthetic regression test for timestamp-key alignment.
Run: python test_tir_keyfix_regression.py
Uses a compatible shared-ledger fixture in this folder; it does not validate the bundled legacy root prediction_ledger.py or real UME/KRX connectivity.
