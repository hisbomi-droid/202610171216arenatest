# -*- coding: utf-8 -*-
"""
test_tir_keyfix_regression.py
=======================================================================
tir_reflection_backtest_v1_connected_timestamp_key_fixed.py 의 키 정합성 수정을
3가지 인덱스 형태에서 회귀 시험한다 (2026-10-09).

시험 형태 (사용자 지정):
  A) 날짜(DatetimeIndex) 인덱스
  B) 정수 인덱스 + date 열
  C) 정수 인덱스 + timestamp 열

각 형태에서:
  1) 합성 일봉 300개 생성 → run_backtest_v1() (frozen baseline, 수정 없음)
  2) record_tir_predictions() → ledger에 기록된 건수 n_recorded
  3) evaluate_tir_predictions() → status가 EVALUATED로 바뀐 건수 n_evaluated
  4) 판정: n_recorded > 0 이고 n_recorded == n_evaluated → PASS
     (기록은 됐는데 평가가 0건이면 키 불일치 — 기존 버그 재현)
  5) summarize_tir_predictions() 으로 Wilson CI 표도 정상 출력되는지 확인

사용 방법 (배포 폴더 03_backtest/ 또는 테스트 폴더에서):
    python test_tir_keyfix_regression.py

필요 파일: 같은 폴더에
  - tir_reflection_backtest_v1_connected_timestamp_key_fixed.py
  - prediction_ledger.py (2026-09-26 통합본)

주의: 이 시험은 합성 데이터 기반이다. 실제 KRX/Naver/Yahoo 수신·네트워크
연동은 이 시험의 통과와 무관하게 여전히 미검증 상태다.
"""
import importlib.util
import os
import sys

import numpy as np
import pandas as pd


def _load(filename, alias):
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), filename)
    if not os.path.exists(path):
        raise SystemExit(f"필수 파일 없음: {filename} (같은 폴더에 두세요)")
    spec = importlib.util.spec_from_file_location(alias, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[alias] = mod  # Master Controller와 동일한 등록 방식
    spec.loader.exec_module(mod)
    return mod


tir = _load("tir_reflection_backtest_v1_connected_timestamp_key_fixed.py", "tir_keyfix")
pl = _load("prediction_ledger.py", "prediction_ledger")
sys.modules["prediction_ledger"] = pl  # keyfix의 `import prediction_ledger` 해석용


def make_base_df(n: int = 300, seed: int = 42) -> pd.DataFrame:
    """run_backtest_v1가 요구하는 컬럼을 갖춘 합성 일봉."""
    rng = np.random.default_rng(seed)
    close = 2600.0 + np.cumsum(rng.normal(0, 12.0, n))
    high = close * (1 + np.abs(rng.normal(0, 0.006, n)))
    low = close * (1 - np.abs(rng.normal(0, 0.006, n)))
    spot = close * (1 - rng.normal(0, 0.002, n))
    futures = close * (1 + rng.normal(0, 0.003, n))
    trade_amount = rng.lognormal(mean=20, sigma=0.4, size=n)
    dates = pd.bdate_range("2025-01-02", periods=n)
    return pd.DataFrame({
        "spot_close": spot,
        "futures_close": futures,
        "high": high,
        "low": low,
        "close": close,
        "trade_amount": trade_amount,
        "date": dates,
        "timestamp": dates + pd.Timedelta(hours=15, minutes=30),
    })


def variant_a(base: pd.DataFrame) -> pd.DataFrame:
    """A) 날짜(DatetimeIndex) 인덱스."""
    df = base.copy()
    df.index = pd.DatetimeIndex(df.pop("date"))
    return df.drop(columns=["timestamp"])


def variant_b(base: pd.DataFrame) -> pd.DataFrame:
    """B) 정수 인덱스 + date 열."""
    df = base.copy()
    df = df.reset_index(drop=True)
    return df.drop(columns=["timestamp"])


def variant_c(base: pd.DataFrame) -> pd.DataFrame:
    """C) 정수 인덱스 + timestamp 열."""
    df = base.copy()
    df = df.reset_index(drop=True)
    return df.drop(columns=["date"])


def run_case(name: str, df: pd.DataFrame) -> bool:
    ledger = pl.PredictionLedger()
    bt = tir.run_backtest_v1(df)  # frozen baseline — 수정 없음
    n_sig = int(bt["tir_signal"].fillna(False).sum())
    n_valid = int((bt["tir_signal"].fillna(False) & bt["bounded_success"].notna()).sum())

    n_recorded = tir.record_tir_predictions(bt, ledger, horizon=5)
    tir.evaluate_tir_predictions(bt, ledger)

    df_all = ledger.dataframe()
    n_evaluated = int((df_all["status"] == "EVALUATED").sum()) if not df_all.empty else 0

    summary = tir.summarize_tir_predictions(ledger)
    summary_ok = summary is not None and (summary.empty or "status" in summary.columns)

    passed = (n_recorded > 0) and (n_recorded == n_evaluated) and summary_ok
    print(f"\n[{name}] signal={n_sig} 기록가능={n_valid} "
          f"기록={n_recorded} 평가(EVALUATED)={n_evaluated} "
          f"요약={'OK' if summary_ok else 'FAIL'} → {'PASS' if passed else 'FAIL'}")
    if not summary.empty:
        print(summary.to_string(index=False))
    if not passed:
        bad = df_all[df_all["status"] == "PENDING"] if not df_all.empty else df_all
        if not bad.empty:
            print("  PENDING 잔존 샘플:", bad["timestamp"].head(3).tolist())
    return passed


def main():
    base = make_base_df()
    results = {
        "A) 날짜(DatetimeIndex) 인덱스": run_case("A", variant_a(base)),
        "B) 정수 인덱스 + date 열": run_case("B", variant_b(base)),
        "C) 정수 인덱스 + timestamp 열": run_case("C", variant_c(base)),
    }
    print("\n" + "=" * 60)
    for k, v in results.items():
        print(f"  {'✅' if v else '❌'} {k}")
    print("=" * 60)
    if all(results.values()):
        print("전체 PASS — keyfix 키 정합성 확인. 기록 n건 → 평가 n건 일치.")
        return 0
    print("FAIL 존재 — 키 불일치 형태가 남아 있습니다.")
    return 1


if __name__ == "__main__":
    sys.exit(main())