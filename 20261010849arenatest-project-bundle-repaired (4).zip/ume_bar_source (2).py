"""UME BAR SOURCE — UME(Market)를 kospi_arena.data_port 의 BarSource 규격으로 감싸는 어댑터.

위치: 01_strategy/kospi_arena/ume_bar_source.py  (data_port.py 와 같은 패키지)

배경(2026-10-10): kospi_master_controller 가 `UMEBarSource` 를 호출하지만 data_port.py 에는
BarSource Protocol / to_arena_bars() / contract_report() 만 있고 이 클래스가 없어서
`UME_AttributeError` 로 demo_replay(fallback) 에 머물렀다. data_port.py 는 원본 그대로 두고,
이 어댑터를 별도 파일로 추가한다.

이 파일이 하는 일은 '호출·전달'뿐이다. 데이터를 만들어 채우거나 값을 고치지 않는다.
  - UME Market(...).market(symbol, timeframe, count) 의 결과 표를 그대로 돌려준다.
    (컬럼: source, timestamp, open, high, low, close, volume, quality — symbol/trade_amount 없음)
  - symbol 과 trade_amount 보충은 data_port.to_arena_bars(symbol=..., derive_trade_amount=True)
    가 명시 옵션으로 처리한다(컨트롤러가 호출).
  - start/end 가 주어지면 timestamp 로 '걸러내기'만 한다(UME 는 count 기준 조회만 지원).
  - 어느 원천(krx/naver/yahoo)이 실제로 응답했는지는 last_report["used"] 에 남는다.
"""
from __future__ import annotations

from typing import List, Optional

import pandas as pd


class UMEBarSource:
    """data_port.BarSource 규격(name 속성 + fetch_bars)을 만족하는 UME 어댑터."""

    name = "ume"

    def __init__(self, providers: Optional[List[str]] = None, count: int = 200,
                 timeframe: str = "1d", fetch_mode: str = "fallback", engine=None) -> None:
        self.providers = list(providers) if providers else ["krx", "naver", "yahoo"]
        self.count = int(count)
        self.timeframe = timeframe
        self.fetch_mode = fetch_mode
        self._engine = engine          # 테스트에서 가짜 엔진을 주입할 수 있다
        self.last_report: dict = {}    # UME 가 남긴 원천별 성공/실패 내역

    def _get_engine(self):
        if self._engine is None:
            from universal_quant_engine import Market  # 지연 import: 경로가 잡힌 뒤에만 필요
            self._engine = Market(providers=self.providers, fetch_mode=self.fetch_mode)
        return self._engine

    def fetch_bars(self, symbol: str, start: Optional[str] = None,
                   end: Optional[str] = None) -> pd.DataFrame:
        engine = self._get_engine()
        df = engine.market(symbol, timeframe=self.timeframe, count=self.count)
        self.last_report = dict(getattr(engine, "last_report", {}) or {})
        if df is None or df.empty:
            raise ValueError("UME returned no bars")
        if start is not None or end is not None:
            ts = pd.to_datetime(df["timestamp"])
            keep = pd.Series(True, index=df.index)
            if start is not None:
                keep &= ts >= pd.Timestamp(start)
            if end is not None:
                keep &= ts <= pd.Timestamp(end)
            df = df.loc[keep].reset_index(drop=True)
            if df.empty:
                raise ValueError(f"UME bars empty after start/end filter ({start}~{end})")
        return df
