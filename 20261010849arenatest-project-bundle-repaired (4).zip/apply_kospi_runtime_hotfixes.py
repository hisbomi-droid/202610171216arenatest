# Apply targeted hotfixes to a workspace copy; creates .runtime_fixed.py files and never overwrites originals.
from pathlib import Path
import sys

ROOT = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
REPLACEMENTS = {
    "kospi_master_controller (4).py": [(
        '"phase": phase.value,',
        '"phase": getattr(phase, "value", str(phase)),',
    )],
    "kospi_cockpit_sensor_hub_v1.1.py": [(
        'intraday.index.date.map(lambda d: bool(event_flags.get(d, False)))',
        'pd.Series(intraday.index.date, index=intraday.index).map(lambda d: bool(event_flags.get(d, False)))',
    )],
    "tir_reflection_backtest_v1.py": [(
        'row.get("timestamp", row.name if hasattr(row, "keys") else "unknown")',
        'row.get("timestamp", getattr(row, "name", "unknown"))',
    )],
}

for name, replacements in REPLACEMENTS.items():
    src = ROOT / name
    if not src.exists():
        print(f"SKIP (not found): {name}")
        continue
    text = src.read_text(encoding="utf-8")
    changed = 0
    for old, new in replacements:
        if old in text:
            text = text.replace(old, new)
            changed += 1
        else:
            print(f"NOTE (pattern not found; version may differ): {name}: {old}")
    if changed:
        out = src.with_name(src.stem + ".runtime_fixed" + src.suffix)
        out.write_text(text, encoding="utf-8")
        print(f"WROTE: {out.name} ({changed} replacement(s))")
    else:
        print(f"NO CHANGE: {name}")
