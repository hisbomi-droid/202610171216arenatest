from __future__ import annotations

import json
import os
from typing import Any, Dict, List

import pandas as pd


class PredictionLedger:
    def __init__(self):
        self.records: List[Dict[str, Any]] = []
        self.path: str = ""

    def load(self, path: str, legacy_symbol: str = "KOSPI") -> "PredictionLedger":
        self.path = path
        self.records = []
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as fh:
                for line in fh:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        self.records.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
        return self

    def record(self, task: str, prediction: Dict[str, Any], actual: Any, timestamp: str, symbol: str = "KOSPI", source: str = "demo") -> Dict[str, Any]:
        payload = {
            "task": task,
            "prediction": prediction,
            "actual": actual,
            "timestamp": timestamp,
            "symbol": symbol,
            "source": source,
        }
        self.records.append(payload)
        return payload

    def save(self, path: str) -> None:
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with open(path, "w", encoding="utf-8") as fh:
            for row in self.records:
                fh.write(json.dumps(row, ensure_ascii=False) + "\n")

    def evaluate(self, actual_series: Any) -> pd.DataFrame:
        if isinstance(actual_series, pd.Series):
            series = actual_series.reset_index(drop=True)
        else:
            series = pd.Series(actual_series)
        if self.records:
            out = pd.DataFrame(self.records)
            out["actual"] = out.get("actual", 0)
            return out
        return pd.DataFrame({"task": [], "actual": []})

    def evaluate_binary_events(self) -> pd.DataFrame:
        return pd.DataFrame({"task": ["binary_event"], "n": [len(self.records)]})

    def summarize(self) -> pd.DataFrame:
        return pd.DataFrame({"task": [r.get("task", "unknown") for r in self.records]})


class OOSAnalyzer:
    def summarize(self, ledger: PredictionLedger) -> pd.DataFrame:
        rows = []
        for item in leaderboard(ledger.records):
            rows.append({"task": item["task"], "n": item["n"]})
        return pd.DataFrame(rows)

    def summarize_binary_events(self, ledger: PredictionLedger) -> pd.DataFrame:
        rows = []
        for item in leaderboard(ledger.records):
            if item["task"] == "binary_event":
                rows.append({"task": "binary_event", "n": item["n"]})
        return pd.DataFrame(rows if rows else [{"task": "binary_event", "n": 0}])


def leaderboard(records: List[Dict[str, Any]]) -> List[Dict[str, int]]:
    counts: Dict[str, int] = {}
    for item in records:
        task = str(item.get("task", "unknown"))
        counts[task] = counts.get(task, 0) + 1
    return [{"task": task, "n": n} for task, n in sorted(counts.items())]
