from __future__ import annotations

from typing import Any, Dict, List

import pandas as pd


def run_backtest_v1(df_daily: pd.DataFrame) -> pd.DataFrame:
    if df_daily is None or df_daily.empty:
        raise ValueError("TIR backtest requires a non-empty daily DataFrame")
    x = df_daily.copy()
    x["ret"] = x["close"].pct_change().fillna(0.0)
    x["signal"] = x["ret"].gt(0.01).astype(int)
    x["tir_event"] = x["ret"].abs().gt(0.015)
    x["state"] = x["ret"].apply(lambda r: "up" if r > 0.01 else "down" if r < -0.01 else "flat")
    return x


def classify_v2_states(tir_df: pd.DataFrame) -> pd.DataFrame:
    df = tir_df.copy()
    df["v2_state"] = df["state"].map({"up": "BULLISH", "down": "BEARISH", "flat": "NEUTRAL"})
    return df


def compute_breakout_forward(v2_df: pd.DataFrame) -> pd.DataFrame:
    df = v2_df.copy()
    df["breakout_forward"] = df["v2_state"].eq("BULLISH").astype(int)
    return df


def compare_with_baseline(v2_df: pd.DataFrame) -> pd.DataFrame:
    if v2_df.empty:
        return pd.DataFrame(columns=["group", "n", "rate", "ci_lower", "ci_upper"])
    grouped = v2_df.groupby("v2_state").size().reset_index(name="n")
    grouped["rate"] = grouped["n"] / grouped["n"].sum()
    grouped["ci_lower"] = grouped["rate"] - 0.05
    grouped["ci_upper"] = grouped["rate"] + 0.05
    grouped = grouped.rename(columns={"v2_state": "group"})
    return grouped[["group", "n", "rate", "ci_lower", "ci_upper"]]


def record_tir_predictions(df: pd.DataFrame, ledger: Any, horizon: int = 5, symbol: str = "KOSPI", source: str = "demo") -> int:
    if df is None or df.empty:
        return 0
    rows = df.tail(max(1, int(horizon))).to_dict(orient="records")
    if hasattr(ledger, "record"):
        for row in rows:
            ledger.record(
                task="binary_event",
                prediction={"signal": "up" if float(row.get("ret", 0.0)) >= 0 else "down"},
                actual=float(row.get("close", 0.0)),
                timestamp=str(row.get("timestamp", row.name if hasattr(row, "keys") else "unknown")),
                symbol=symbol,
                source=source,
            )
        return len(rows)
    return 0


def evaluate_tir_predictions(df: pd.DataFrame, ledger: Any) -> Any:
    if hasattr(ledger, "evaluate"):
        return ledger.evaluate(df["close"]) if "close" in df.columns else ledger.evaluate(df)
    return None


def summarize_tir_predictions(ledger: Any) -> Any:
    if hasattr(ledger, "summarize"):
        return ledger.summarize()
    return pd.DataFrame()
