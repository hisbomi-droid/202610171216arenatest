#!/usr/bin/env python3
"""Patch only the TIR ledger adapter's timestamp-key alignment.

Usage:
  python patch_tir_timestamp_key_alignment.py /path/to/tir_reflection_backtest_v1_connected.py

Writes <stem>.timestamp_key_fixed.py beside the input; never overwrites the input.
Baseline functions and load_market_data() are left untouched.
"""
from __future__ import annotations
import ast
import sys
from pathlib import Path
from typing import Optional

HELPER = '''\ndef _tir_ledger_timestamp_frame(df: pd.DataFrame) -> pd.DataFrame:
    """Return a copy with a canonical DatetimeIndex shared by record and evaluate.

    Explicit timestamp/date columns take precedence over a possibly integer index.
    If neither exists, a datetime-like index is accepted; an integer-only index is
    rejected instead of silently becoming nanoseconds after the Unix epoch.
    """
    out = df.copy()
    source = None
    for col in ("timestamp", "date", "datetime", "time"):
        if col in out.columns:
            source = out[col]
            break
    if source is None:
        if isinstance(out.index, pd.DatetimeIndex):
            source = pd.Series(out.index, index=out.index)
        else:
            if pd.api.types.is_numeric_dtype(out.index.dtype):
                raise ValueError(
                    "TIR ledger needs a timestamp/date/datetime/time column or a "
                    "DatetimeIndex; refusing to interpret integer row labels as dates."
                )
            parsed_index = pd.to_datetime(out.index, errors="coerce")
            if parsed_index.isna().any():
                raise ValueError(
                    "TIR ledger needs a timestamp/date/datetime/time column or a "
                    "DatetimeIndex; refusing to interpret row labels as dates."
                )
            source = pd.Series(parsed_index, index=out.index)
    parsed = pd.to_datetime(source, errors="coerce")
    if parsed.isna().any():
        bad = int(parsed.isna().sum())
        raise ValueError(f"TIR ledger timestamp column contains {bad} invalid value(s).")
    out.index = pd.DatetimeIndex(parsed, name="timestamp")
    return out

'''

RECORD = '''def record_tir_predictions(df: pd.DataFrame, ledger, horizon: int = 5,
                           symbol: str = "KOSPI", source: str = "tir_v1") -> int:
    """Record TIR binary-event predictions using the canonical outcome timestamp."""
    if not _LEDGER_AVAILABLE:
        raise RuntimeError("prediction_ledger 모듈을 찾을 수 없어 TIR 예측을 기록할 수 없습니다.")
    required = {"tir_signal", "bounded_success", "close"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"TIR ledger adapter required columns missing: {sorted(missing)}")

    keyed = _tir_ledger_timestamp_frame(df)
    added = 0
    valid = keyed["tir_signal"].fillna(False).astype(bool) & keyed["bounded_success"].notna()
    for ts, row in keyed.loc[valid].iterrows():
        rec = _pl.PredictionRecord(
            timestamp=str(pd.Timestamp(ts)),
            model="tir_v1",
            task="binary_event",
            horizon=horizon,
            regime="TIR_SIGNAL",
            prediction="TRUE",
            p_up=None,
            predicted_return=None,
            price_at_prediction=float(row["close"]),
            source=source,
            symbol=symbol,
        )
        if ledger.add(rec):
            added += 1
    return added
'''

EVALUATE = '''def evaluate_tir_predictions(df: pd.DataFrame, ledger) -> None:
    """Evaluate outcomes on exactly the same canonical timestamp key used at record time."""
    if not _LEDGER_AVAILABLE:
        raise RuntimeError("prediction_ledger 모듈을 찾을 수 없어 TIR 예측을 평가할 수 없습니다.")
    if "bounded_success" not in df.columns:
        raise ValueError("run_backtest_v1() 결과에 bounded_success가 없습니다.")
    keyed = _tir_ledger_timestamp_frame(df)
    outcomes = keyed["bounded_success"].copy()
    outcomes.index = keyed.index
    ledger.evaluate_binary_events(outcomes, at_prediction_timestamp=True)
'''


def replace_function(src: str, name: str, replacement: str) -> str:
    tree = ast.parse(src)
    funcs = [n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == name]
    if len(funcs) != 1:
        raise ValueError(f"Expected exactly one top-level function {name!r}; found {len(funcs)}")
    node = funcs[0]
    # AST end_lineno includes decorators, but these functions have no decorators.
    lines = src.splitlines(keepends=True)
    start = node.lineno - 1
    end = node.end_lineno
    replacement = replacement.rstrip() + "\n\n"
    return "".join(lines[:start]) + replacement + "".join(lines[end:])


def adapter_provider_hint(src: str, src_path: Path) -> Optional[str]:
    """Find a local module re-exporting the TIR adapter functions."""
    tree = ast.parse(src)
    adapter_names = {
        "record_tir_predictions",
        "evaluate_tir_predictions",
        "summarize_tir_predictions",
    }
    for node in tree.body:
        if not isinstance(node, ast.ImportFrom) or not node.module:
            continue
        imported_names = {alias.name for alias in node.names}
        if not adapter_names.issubset(imported_names):
            continue
        parts = node.module.split(".")
        module_path = src_path.parent.joinpath(*parts).with_suffix(".py")
        if module_path.is_file():
            return str(module_path)
    return None


def main() -> int:
    if len(sys.argv) != 2:
        print(__doc__)
        return 2
    src_path = Path(sys.argv[1]).resolve()
    if not src_path.is_file():
        print(f"ERROR: file not found: {src_path}", file=sys.stderr)
        return 2
    source = src_path.read_text(encoding="utf-8")
    tree = ast.parse(source)
    functions = {
        node.name
        for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
    }
    missing = {"record_tir_predictions", "evaluate_tir_predictions"} - functions
    if missing:
        provider = adapter_provider_hint(source, src_path)
        if provider:
            print(
                f"ERROR: {src_path} is a re-export wrapper; it does not define "
                f"{', '.join(sorted(missing))}. Patch the adapter implementation "
                f"instead: {provider}",
                file=sys.stderr,
            )
        else:
            print(
                f"ERROR: adapter functions not found in {src_path}: "
                f"{', '.join(sorted(missing))}",
                file=sys.stderr,
            )
        return 2

    required_functions = {
        "record_tir_predictions",
        "evaluate_tir_predictions",
        "summarize_tir_predictions",
    }
    if not required_functions.issubset(functions):
        missing = required_functions - functions
        print(
            f"ERROR: controller adapter functions missing from {src_path}: "
            f"{', '.join(sorted(missing))}",
            file=sys.stderr,
        )
        return 2

    # Replace adapters first, then insert helper directly before record function.
    source = replace_function(source, "evaluate_tir_predictions", EVALUATE)
    source = replace_function(source, "record_tir_predictions", RECORD)
    if "def _tir_ledger_timestamp_frame(" not in source:
        marker = "def record_tir_predictions("
        pos = source.find(marker)
        if pos < 0:
            raise ValueError("record_tir_predictions marker not found after replacement")
        source = source[:pos] + HELPER.lstrip() + source[pos:]
    # Validate syntax before writing.
    ast.parse(source)
    out_path = src_path.with_name(src_path.stem + ".timestamp_key_fixed.py")
    if out_path.exists():
        raise FileExistsError(f"Refusing to overwrite existing output: {out_path}")
    out_path.write_text(source, encoding="utf-8")
    print(f"Wrote: {out_path}")
    print("Changed only _tir_ledger_timestamp_frame, record_tir_predictions, and evaluate_tir_predictions.")
    print("load_market_data() and baseline/v2 functions were preserved verbatim.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
